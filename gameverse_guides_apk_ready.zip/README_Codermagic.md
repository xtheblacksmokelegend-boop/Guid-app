# GameVerse Guides - APK Build (Codemagic) - Mobile-friendly Guide

Du hast nur ein Handy? Kein Problem — mit Codemagic kannst du die APK online bauen.

## Schritt 1: Zip herunterladen
- Lade die ZIP herunter: gameverse_guides_apk_ready.zip (dieser Ordner).

## Schritt 2: Codemagic öffnen
1. Öffne https://codemagic.io/start/ im Handy-Browser.
2. Erstelle ein Konto oder melde dich an (Google möglich).

## Schritt 3: Neues Projekt hochladen
1. Wähle "Upload project" oder "Upload source code" (Codemagic erkennt Flutter automatisch).
2. Lade die ZIP-Datei hoch.

## Schritt 4: Build starten
1. Wähle Workflow "Flutter" (Standard).
2. Klicke auf "Start build" oder "Build".
3. Warte einige Minuten — Codemagic baut die APK.

## Schritt 5: APK herunterladen
1. Nach erfolgreichem Build findest du das APK im Abschnitt "Artifacts".
2. Lade die APK direkt auf dein Handy herunter und installiere sie (evtl. erlauben von "Install unknown apps").

## Hinweise
- Das Projekt ist ohne Login und enthält Demo-Guides + Tierlists.
- Wenn Codemagic zusätzliche Felder verlangt (z. B. package name), nutze com.example.gameverse_guides.
- Für Google Play Signierung brauchst du einen Keystore; für Testinstallationen ist das nicht nötig.
