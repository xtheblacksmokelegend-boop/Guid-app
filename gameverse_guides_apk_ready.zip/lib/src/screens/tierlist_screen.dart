import 'package:flutter/material.dart';
import '../data/demo_data.dart';

class TierlistScreen extends StatelessWidget {
  const TierlistScreen({super.key});

  Color colorForRank(String rank) {
    switch(rank) {
      case 'S': return const Color(0xFFFFD700); // gold
      case 'A': return const Color(0xFF00FF99); // greenish
      case 'B': return const Color(0xFF00FFFF); // cyan
      case 'C': return const Color(0xFFFF77FF); // pink
      default: return Colors.white;
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Tier Lists')),
      body: ListView(
        padding: const EdgeInsets.all(12),
        children: [
          const Text('New World', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: Colors.white)),
          const SizedBox(height: 8),
          ...?tierLists['newworld']?.map((t) => Card(
            color: const Color(0xFF0F1113),
            child: ListTile(
              leading: CircleAvatar(backgroundColor: colorForRank(t['rank']!), child: Text(t['rank']!, style: const TextStyle(color: Colors.black, fontWeight: FontWeight.bold))),
              title: Text(t['item']!, style: const TextStyle(color: Colors.white)),
              subtitle: Text(t['note']!, style: const TextStyle(color: Colors.white70)),
            ),
          )).toList(),
          const SizedBox(height: 16),
          const Text('Rust', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: Colors.white)),
          const SizedBox(height: 8),
          ...?tierLists['rust']?.map((t) => Card(
            color: const Color(0xFF0F1113),
            child: ListTile(
              leading: CircleAvatar(backgroundColor: colorForRank(t['rank']!), child: Text(t['rank']!, style: const TextStyle(color: Colors.black, fontWeight: FontWeight.bold))),
              title: Text(t['item']!, style: const TextStyle(color: Colors.white)),
              subtitle: Text(t['note']!, style: const TextStyle(color: Colors.white70)),
            ),
          )).toList(),
        ],
      ),
    );
  }
}
