import 'package:flutter/material.dart';
import '../data/demo_data.dart';
import 'guide_view_screen.dart';

class GameScreen extends StatelessWidget {
  final String gameId;
  final String gameName;
  const GameScreen({super.key, required this.gameId, required this.gameName});

  @override
  Widget build(BuildContext context) {
    final guides = demoGuides[gameId] ?? [];
    return Scaffold(
      appBar: AppBar(title: Text(gameName)),
      body: ListView.builder(
        padding: const EdgeInsets.all(12),
        itemCount: guides.length,
        itemBuilder: (context, index) {
          final g = guides[index];
          return Card(
            color: const Color(0xFF0F1113),
            margin: const EdgeInsets.only(bottom: 10),
            child: ListTile(
              title: Text(g['title']!, style: const TextStyle(color: Colors.white)),
              subtitle: Text(g['content']!, style: const TextStyle(color: Colors.white70)),
              trailing: const Icon(Icons.chevron_right, color: Colors.white70),
              onTap: () {
                Navigator.of(context).push(MaterialPageRoute(builder: (_) => GuideViewScreen(title: g['title']!, content: g['content']!)));
              },
            ),
          );
        },
      ),
    );
  }
}
