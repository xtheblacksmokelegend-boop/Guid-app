import 'package:flutter/material.dart';
import 'screens/home_screen.dart';
import 'utils/theme.dart';

class GameVerseApp extends StatelessWidget {
  const GameVerseApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'GameVerse Guides',
      debugShowCheckedModeBanner: false,
      theme: ThemeConfig.darkTheme,
      home: const HomeScreen(),
    );
  }
}
