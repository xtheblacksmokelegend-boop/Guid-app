import 'package:flutter/material.dart';

class ThemeConfig {
  static const Color background = Color(0xFF0D0D0F);
  static const Color neonBlue = Color(0xFF00FFFF);
  static const Color neonPink = Color(0xFFFF00FF);
  static const Color neonGold = Color(0xFFFFD700);

  static final ThemeData darkTheme = ThemeData.dark().copyWith(
    scaffoldBackgroundColor: background,
    colorScheme: ColorScheme.dark(primary: neonBlue, secondary: neonPink),
    appBarTheme: const AppBarTheme(backgroundColor: Color(0xFF0B0B0C), elevation: 2),
    textTheme: const TextTheme(
      headline6: TextStyle(color: Colors.white, fontSize: 20, fontWeight: FontWeight.bold),
      bodyText2: TextStyle(color: Colors.white70, fontSize: 14),
    ),
    elevatedButtonTheme: ElevatedButtonThemeData(
      style: ElevatedButton.styleFrom(backgroundColor: neonBlue),
    ),
  );
}
