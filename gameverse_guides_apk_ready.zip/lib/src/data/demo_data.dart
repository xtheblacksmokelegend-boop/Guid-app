final demoGames = [
  {'id': 'dayz', 'name': 'DayZ'},
  {'id': 'newworld', 'name': 'New World'},
  {'id': 'rust', 'name': 'Rust'},
];

final demoGuides = {
  'dayz': [
    {'title': 'Lagerbau Basics', 'content': 'Baue ein sicheres Lager: Wähle erhöhte Positionen, nutze Zäune und Fallen.'},
    {'title': 'Food & Water', 'content': 'Suche nach Dosen, Wasserfilter herzustellen ist lebenswichtig.'},
  ],
  'newworld': [
    {'title': 'Anfänger-Crafting', 'content': 'Fokussiere auf Sammeln von Holz & Erze; craft einfache Rüstung.'},
    {'title': 'Marktplatz Tipps', 'content': 'Nutze Auktionshäuser und beobachte Preise.'},
  ],
  'rust': [
    {'title': 'Basis-Raid-Strategien', 'content': 'Verstärkung an Türen, Stellung halten, Teamkoordination.'},
    {'title': 'Waffenherstellung', 'content': 'Priorisiere einfache Schusswaffen und Munition.'},
  ],
};

final tierLists = {
  'newworld': [
    {'rank': 'S', 'item': 'Greatsword', 'note': 'Hoher Schaden, vielseitig.'},
    {'rank': 'A', 'item': 'Spear', 'note': 'Gute Reichweite.'},
    {'rank': 'B', 'item': 'Bow', 'note': 'Fernkampf, benötigt Skill.'},
  ],
  'rust': [
    {'rank': 'S', 'item': 'Bolt Action', 'note': 'Hoher Präzisionsschaden.'},
    {'rank': 'A', 'item': 'Assault Rifle', 'note': 'Schnell und zuverlässig.'},
    {'rank': 'B', 'item': 'Handmade Rifle', 'note': 'Gute Balance.'},
  ],
};
